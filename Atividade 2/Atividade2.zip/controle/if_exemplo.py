nota = float(input("Digite sua nota: "))

if nota>=6:
    print("aprovado")
else:
    print("reprovado")

# Equivale a:
# print("Voce esta: ", "aprovado"if nota>=6 else "reprovado")
