
# a = 'texto'
# a = 0
a = -0.01
# a = ''
# a = ' '
# a = []
# a = {}

if a:
    print("verdade")
else:
    print("mentira")