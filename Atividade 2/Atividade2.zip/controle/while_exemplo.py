legal = "nao"

while legal != "sim":
    legal = input("eu sou legal? ")

i = 0

while i < 10:
    i+=1
    print(i)