def somar(x, y):
    return x+y

def ola(nome, idade = 20):
    print(f"Ola, {nome}, voce parece ter {idade} anos")

if __name__ == "__main__":
    print(somar(3,5))