quadrados = [x ** 2 for x in range(1, 11)]

print(quadrados)