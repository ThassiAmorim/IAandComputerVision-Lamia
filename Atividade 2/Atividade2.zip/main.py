print("Hello, World!")

# import pacotes.arquivo

# from tipos import variaveis, basicos

# import tipos.listas
# import tipos.tuplas
# import tipos.conjuntos
# import tipos.dicionario

# import operadores.unarios
# import operadores.aritmeticos
# import operadores.relacionais
# import operadores.atribuicao
# import operadores.logicos
# import operadores.ternario

# import controle.if_exemplo
# import controle.if_exemplo2
# import controle.while_exemplo

from funcoes import basico, args, funcional, map_reduce

# x = 4
# y = 7
# nome = "Amigo"

# basico.ola("Amigo", basico.somar(x,y))
# basico.ola("Amigo")
# basico.ola(idade=30, nome="joao")


# print(args.soma(1,1,1,1,1))
# args.pessoa(nome="onilvo", idade=65)



