x = 3
y = 40

print("se x=3 e y=40 entao x+y=", x+y)
print("se x=3 e y=40 entao x*y=", x*y)
print("se x=3 e y=40 entao x/y=", x/y)
print("se x=3 e y=40 entao x%y=", x%y)

