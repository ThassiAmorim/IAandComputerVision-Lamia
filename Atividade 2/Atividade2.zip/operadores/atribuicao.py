variavel = 60/5

print("A variavel e: ", variavel)
variavel -= 5
print("A variavel -= 5 e: ", variavel)
variavel /= 5
print("A variavel /= 5 e: ", variavel)
variavel %= 5
print("A variavel %= 5 e: ", variavel)
variavel *= 5
print("A variavel *= 5 e: ", variavel)
