a = True
b = 0
c =  False

print("Se tenho a = True e b = 0:\n")

print("a and b: ", a and b)
print("a and c: ", a and c)
print("a or b: ", a or b)
print("a != b: ", a != b)
print("not b: ", not b)
print("a and c or not b: ", a and c or not b)
