x = 5
y = 6

print("Se x=5 e y=6 entao o resultado de \"x > y\" e:", x > y)
print("Se x=5 e y=6 entao o resultado de \"x >= y\" e:", x >= y)
print("Se x=5 e y=5 entao o resultado de \"x >= y\" e:", x >= 5)
print("Se x=5 e y=6 entao o resultado de \"x < y\" e:", x < y)
print("Se x=5 e y=6 entao o resultado de \"x == y\" e:", x == y)
print("Se x=5 e y=6 entao o resultado de \"x != y\" e:", x != y)