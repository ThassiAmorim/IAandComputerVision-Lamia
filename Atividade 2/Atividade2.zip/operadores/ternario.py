vermelho = True


print("\"morango\" if vermelho else \"abacate\", portanto temos: ", "morango" if vermelho else "abacate")