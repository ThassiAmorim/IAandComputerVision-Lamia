variavel = True
print("minha variavel e: ", variavel)
print("Porem se se fizer \"not variavel\" tenho: ", not variavel)

print("caso eu faca \"--3\" tenho: ", --3)