print(__name__)
print(__package__)