# Conjuntos é igual na matematica, não há repetição de elementos 
# e as operações entre conjuntos se mantem

conjunto = {1,4,77,5,8,3,1,77}
print("Conjunto: ", conjunto , "tipo", type(conjunto))

conjunto2 = {1,2,3,4,5,6,7,8}
print("Conjunto2: ", conjunto , "tipo", type(conjunto))

print("conjunto.union(conjunto2) ", conjunto.union(conjunto2) , "tipo", type(conjunto))