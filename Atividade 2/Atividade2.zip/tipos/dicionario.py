# Tipo de dados chave-valor, semelhante a hashs

dicionario = {
    "nome": "Zeca",
    "idade": 35,
    "pais": "brasil"
}

print(" dicionario[nome]: ", dicionario["nome"])
print(" dicionario: ", dicionario)

print("dicionario.keys(): ", dicionario.keys())
print("dicionario.values(): ", dicionario.values())
print("dicionario.items(): ", dicionario.items())
print("type(dicionario.items()): ", type(dicionario.items()))

