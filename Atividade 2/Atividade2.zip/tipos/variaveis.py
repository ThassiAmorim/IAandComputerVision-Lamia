# Strings podem ser definidas como

texto = """
Olá a todos, bem-vindos aos meus codigos
Aproveitem :)
"""

palavra = "abacate"

print(texto, palavra)

# ou pode ser feito:

print(f'{texto} {palavra}')


# Numeros podem ser definidos como

numero_inteiro = 5 

numero_real = 4.58

print(f"\n\nNumero inteiro: {numero_inteiro}, Numero real: {numero_real}"
      f"\nTexto: {texto} Palavra: {palavra}")