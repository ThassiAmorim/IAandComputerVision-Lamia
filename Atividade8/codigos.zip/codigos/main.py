from bs4 import BeautifulSoup
import requests
import re
import time

def find_jobs(user_skills=None):
    html = requests.get('https://www.timesjobs.com/candidate/job-search.html?searchType=personalizedSearch&from=submit&searchTextSrc=&searchTextText=&txtKeywords=python&txtLocation=')
    soup = BeautifulSoup(html.text, 'lxml')
    jobs = soup.find_all('li', class_='clearfix job-bx wht-shd-bx')

    for job in jobs:
        posted = job.find('span', class_='sim-posted')
        if  posted.span.text == 'Posted few days ago':
            company_name = job.find('h3', class_='joblist-comp-name').text.strip()
            skills = re.sub(r'\s+,',',', (job.find('span', class_='srp-skills').text.strip()))
            skills_vector = [skill.strip() for skill in skills.split(',')]
            more_info = job.find('a')['href']
            
            if user_skills is not None:
                for user_skill in user_skills:
                    if any(user_skill.lower() in skill.lower() for skill in skills_vector):
                        print(f'Company Name: {company_name}\nRequired Skills: {skills}\nMore info: {more_info}\n')
                        break
            else:
                print(f'Company Name: {company_name}\nRequired Skills: {skills}\nMore info: {more_info}\n')

        
if __name__ == '__main__':
    user_skills = (input("Which skills do you have (comma separated):"))
    user_skills = re.sub(r'\s+', '', user_skills).split(',')
    find_jobs(user_skills)
    wait = 10
    print(f"Waiting {wait} minutes...")
    time.sleep(wait*60)


